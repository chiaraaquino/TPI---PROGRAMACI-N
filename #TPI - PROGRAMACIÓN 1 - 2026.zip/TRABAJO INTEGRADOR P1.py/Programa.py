import csv    #  importa el módulo csv de Python

#=============================== DEFINICIÓN DE FUNCIONES ===============================#
def cargar_paises():  # def : define (o declara) funciones
    paises = []                                                   # with abre y cierra el archivo automaticamente.       # as : nombra a un archivo abierto para usarlo con with
    ruta = __file__.replace("Programa.py","paises.csv") # busca el CSV en la misma carpeta que desarrollamos el codigo.py

    with open(ruta, "r", encoding="utf-8-sig") as archivo:    # open() : abre un archivo // r : modo lectura // encoding="utf-8" : permite caracteres especiales como tildes y la ñ.
        lector = csv.DictReader(archivo, delimiter=',')   # csv.DictReader() : convierte cada fila automáticamente en un diccionario
        for fila in lector:
            paises.append({                  # cada fila se agrega a la lista paises
                "nombre": fila["nombre"],
                "poblacion": int(fila["poblacion"]),
                "superficie": int(fila["superficie"]),
                "continente": fila["continente"]
                })    
    return paises   # devuelve paises con la info
#-------------------------------------OPCION (0) - MOSTRAR PAISES-------------------------------------#
def mostrar_paises(paises):
    for pais in paises:
        print(f"Nombre: {pais['nombre']}")
        print(f"Población: {pais['poblacion']}")
        print(f"Superficie: {pais['superficie']} km²")
        print(f"Continente: {pais['continente']}")
        print("---")
#-------------------------------------OPCION (1) - AGREGAR PAISES-------------------------------------#
def agregar_pais(paises):   # funcion agregar_pais para la opcion 1
    nombre = input("Ingrese el nombre del país: ")
    poblacion = input("Ingrese la población: ")
    superficie = input("Ingrese la superficie en km²: ")
    continente = input("Ingrese el continente: ")

    if nombre == "" or poblacion == "" or superficie == "" or continente == "":   # valida que ningun dato este vacio.
        print("ERROR: ningún campo puede estar vacío.")
        return
    if not poblacion.isdigit() or not superficie.isdigit():     # se asegura de que poblacion y superficie sean numeros.
        print("ERROR: población y superficie deben ser números enteros.")
        return
    
    datos = {"nombre": nombre, "poblacion": int(poblacion), "superficie": int(superficie), "continente": continente}
    paises.append(datos) # agrega datos a paises

    print("¡País agregado correctamente!")
#-------------------------------------OPCION (2) - ACTUALIZAR PAISES-------------------------------------#
def actualizar_pais(paises):  # funcion actualizar_pais para la opcion 2
    nombre = input("Ingrese el nombre del país a actualizar: ")
    for pais in paises:
        if nombre.lower() == pais["nombre"].lower():
            poblacion = input("Ingrese la población: ")
            superficie = input("Ingrese la superficie en km²: ")

            if not poblacion.isdigit() or not superficie.isdigit():      # se asegura de que poblacion y superficie sean numeros.
                print("ERROR: población y superficie deben ser números enteros.")
                return
            
            pais["poblacion"] = int(poblacion)     # actualiza la lista
            pais["superficie"] = int(superficie)
            print("¡Se actualizó con éxito!")
            return
#-------------------------------------OPCION (3) - BUSCAR PAISES POR NOMBRES-------------------------------------#
def buscar_pais(paises): # funcion buscar_pais para la opcion 3
    nombre = input("Ingrese el nombre del país: ")
    encontrados = []
    
    for pais in paises:   # pais busca en paises
        if nombre.lower() in pais["nombre"].lower():  #  pais["nombre"] : accede al valor del nombre de ese pais
            encontrados.append(pais)    # el pais se guarda en encontrados
    
    if len(encontrados) == 0:      # len() cuenta cuantos elementos tiene una lista
        print("No se encontraron países.")
    else:
        mostrar_paises(encontrados)
#-------------------------------------OPCION (4) - FILTRAR PAISES-------------------------------------#
def filtrar_paises(paises):  #  funcion filtrar_paises para la opcion 4
    print("\n=== FILTRAR PAÍSES ===")   # SUB MENÚ
    print("1. Por continente")
    print("2. Por rango de población")
    print("3. Por rango de superficie")
    opcion = input("Elegí una opción: ")

    if opcion == "1":
        continente = input("Ingrese el continente: ")
        encontrados = []
        for pais in paises:
            if continente.lower() == pais["continente"].lower():
                encontrados.append(pais)
        
        if len(encontrados) == 0:
            print("No se encontraron países en ese continente.")
        else:
            mostrar_paises(encontrados)

    if opcion == "2":
        minimo = input("Ingrese la población mínima: ")
        maximo = input("Ingrese la población máxima: ")

        if not minimo.isdigit() or not maximo.isdigit():
            print("ERROR: deben ser números enteros.")
            return
        encontrados = []

        for pais in paises:   
            if int(minimo) <= pais["poblacion"] <= int(maximo):  # "si la población del país está entre el mínimo y el máximo"
                encontrados.append(pais)
        
        if len(encontrados) == 0:
            print("No se encontraron países en ese rango de población.")
        else:
            mostrar_paises(encontrados)

    if opcion == "3":
        minimo = input("Ingrese la superficie mínima: ")
        maximo = input("Ingrese la superficie máxima: ")

        if not minimo.isdigit() or not maximo.isdigit():
            print("ERROR: deben ser números enteros.")
            return
        encontrados = []

        for pais in paises:   
            if int(minimo) <= pais["superficie"] <= int(maximo):
                encontrados.append(pais)
        
        if len(encontrados) == 0:
            print("No se encontraron países en ese rango de superficie.")
        else:
            mostrar_paises(encontrados)
#-------------------------------------OPCION (5) - ORDENAR PAISES-------------------------------------#
def ordenar_nombre(pais): 
    return pais["nombre"]

def ordenar_poblacion(pais):
    return pais["poblacion"]

def ordenar_superficie(pais):
    return pais["superficie"]

def ordenar_paises(paises):                              #Menu interactivo para ordenar los paises
    while True:                                          #Repite el menu hasta que el usuario finalice la interacción
        print("-----------ORDENAR PAISES-----------") 
        print("(1). Por nombre (A-Z)")
        print("(2). Por nombre (Z-A)")
        print("(3). Por poblacion de menor a mayor")
        print("(4). Por poblacion de mayor a menor")
        print("(5). Por superficie de menor a mayor")
        print("(6). Por superficie de mayor a menor")
        print("(7). Volver al menu principal")
        opciones = input ("Ordenar por: ").strip() #El strip elimina los espacios
        
        if opciones == "1":
            paises.sort(key=ordenar_nombre)
            print("-----------Paises ordenados por nombre (A-Z)-----------")

        elif opciones == "2":
            paises.sort(key=ordenar_nombre, reverse=True)
            print("-----------Paises ordenados por nombre (Z-A)-----------")
       
        elif opciones == "3":
            paises.sort(key=ordenar_poblacion)
            print("-----------Paises ordenados por población (menor a mayor)-----------")

        elif opciones == "4":
            paises.sort(key=ordenar_poblacion, reverse=True)
            print("-----------Paises ordenados por población (mayor a menor)-----------")
    
        elif opciones == "5":
            paises.sort(key=ordenar_superficie)
            print("-----------Paises ordenados por superficie (menor a mayor)-----------")

        elif opciones == "6":
            paises.sort(key=ordenar_superficie, reverse=True)
            print("-----------Paises ordenados por superficie (mayor a menor)-----------")

        elif opciones == "7":
            print ("Volviendo a menu principal")
            break
        
        else:
            print("Ingrese una opcion numerica del menu")
            continue

        for p in paises:                                               #Permite visualizar la lista de paises organizados una vez seleccionado el orden
            print(f"{p['nombre']:} | Población {p['poblacion']:,} | Superficie: {p['superficie']:,} km2")
#-------------------------------------OPCION (6) - MOSTRAR ESTADISTICAS-------------------------------------#
def comparar_nombre(pais):
    return pais["nombre"]

def comparar_poblacion(pais):
    return pais["poblacion"]

def comparar_superficie(pais):
    return pais["superficie"]

def mostrar_estadisticas(paises):                                       #Si la lista de paises está vacia (csv vacio), termina el programa
    if len(paises) == 0:
        print("No hay paises añadidos")
        return
        
    pais_max_poblacion = max(paises, key=comparar_poblacion)
    pais_min_poblacion = min(paises, key=comparar_poblacion)

    pais_max_superficie = max(paises, key=comparar_superficie)
    pais_min_superficie = min(paises, key=comparar_superficie)

    total_poblacion = 0                                                 #Calculño de promedio de poblacion
    for p in paises:                                                    #Suma la poblacion de los paises
        total_poblacion = total_poblacion + p["poblacion"]
    promedio_poblacion = total_poblacion / len(paises)

    total_superficie = 0                                                #Calculo de promedio de superficie
    for p in paises:                                                    #Suma la superficie de los paises
        total_superficie = total_superficie + p["superficie"]
    promedio_superficie = total_superficie / len(paises)

    print ("------------DATOS ESTADISTICOS------------")
    print("Mayor población:", pais_max_poblacion["nombre"], "-", pais_max_poblacion["poblacion"])
    print("Menor población:", pais_min_poblacion["nombre"], "-", pais_min_poblacion["poblacion"])

    print("Mayor superficie:", pais_max_superficie["nombre"], "-", pais_max_superficie["superficie"])
    print("Menor superficie:", pais_min_superficie["nombre"], "-", pais_min_superficie["superficie"])

    print("Promedio de poblacion:", round(promedio_poblacion, 2))       #La funcion round permite mostrar los numeros decimales redondeados en 2
    print("Promedio de superficie:", round(promedio_superficie, 2))

def mostrar_estadisticas_continentes(paises):                                  
    print("Cantidad de paises por continente:")
    paises_continente = {}                                             #Diccionario de continentes

    for p in paises:                                                   #Recorre los paises del csv
        continente = p["continente"]                                   #Guarda los continentes de los paises
        if continente in paises_continente:
            paises_continente[continente] += 1                         #Si el continente esta en el diccionario suma 1
        else:
            paises_continente[continente] = 1                          #Si el continente no esta en el diccionario, lo agrega y suma 1
    for continente, cantidad in paises_continente.items():             #Recorre el diccionario
        print(f"{continente}: {cantidad} paises")                      #Imprime valores
            
#=============================== MENÚ ===============================#
def mostrar_menu(paises):
    while True:
        print("\n=== GESTIÓN DE PAÍSES ===")
        print("0. Mostrar lista de paises")
        print("1. Agregar país")
        print("2. Actualizar datos")
        print("3. Buscar país por nombre")
        print("4. Filtrar países")
        print("5. Ordenar países")
        print("6. Mostrar estadísticas")
        print("7. Salir")
        opcion = input("Elegí una opción: ")

        if opcion == "0":   # MOSTRAR PAISES
            mostrar_paises(paises)

        elif opcion == "1":   # AGREGAR PAÍS
            agregar_pais(paises)

        elif opcion == "2":   # ACTUALIZAR DATOS
            actualizar_pais(paises)

        elif opcion == "3":   # BUSCAR PAÍS POR NOMBRE
            buscar_pais(paises)

        elif opcion == "4":   # FILTRAR PAISES
            filtrar_paises(paises)

        elif opcion == "5": # ORDENAR PAISES
            ordenar_paises(paises)

        elif opcion == "6": # ESTADISTICAS
            mostrar_estadisticas(paises)
            mostrar_estadisticas_continentes(paises)

        elif opcion == "7":   # SALIR
            print("¡Hasta luego!")
            break
#-------------------------------------EJECUCION-------------------------------------#
paises = cargar_paises()
mostrar_menu(paises)



